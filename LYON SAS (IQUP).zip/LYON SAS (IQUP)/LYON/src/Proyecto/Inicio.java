
package Proyecto;
public class Inicio {
    public static void main (String args[]){
        java.awt.EventQueue.invokeLater(new Runnable(){
            
        public void run(){
            new IQup2().setVisible(true);
        }
    });
    }
}
